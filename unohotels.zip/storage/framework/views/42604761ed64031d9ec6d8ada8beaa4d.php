

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="page-inner">
        <div class="page-header">
            <h3 class="fw-bold mb-3">Hotel List</h3>
            <ul class="breadcrumbs mb-3">
                <li class="nav-home">
                    <a href="<?php echo e(route('dashboard')); ?>">
                        <i class="icon-home"></i>
                    </a>
                </li>
                <li class="separator">
                    <i class="icon-arrow-right"></i>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('hotels.create')); ?>">Add New Hotel</a>
                </li>
                <li class="separator">
                    <i class="icon-arrow-right"></i>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('hotels.index')); ?>">Hotel List</a>
                </li>
            </ul>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Hotel List</h4>
                        <!-- Success Message -->
                        <?php if(session('success')): ?>
                            <div class="alert alert-success" id="message" role="alert">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                      <div class="table-responsive">
                        <div id="basic-datatables_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4">
                            <div class="card mb-3">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-sm-12 col-md-6">
                                            <div class="dataTables_length" id="basic-datatables_length">
                                                
                                            </div>
                                        </div>
                                        <div class="col-sm-12 col-md-6">
                                            <div id="basic-datatables_filter" class="dataTables_filter">
                                                <label>Search:
                                                    <input type="search" class="form-control form-control-sm"
                                                        placeholder="" aria-controls="basic-datatables">
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Country</th> <!-- First column for country -->
                                        <th>Destination</th> <!-- Second column for destination -->
                                        <th>Hotel Name</th> <!-- Third column for hotel name -->
                                        <th>Image</th> <!-- Fourth column for image -->
                                        <th>Actions</th> <!-- Fifth column for actions -->
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php echo e($hotel->destination->country ? $hotel->destination->country->country_name : 'No country'); ?>

                                            </td>
                                            <!-- Displaying country name -->
                                            <td><?php echo e($hotel->destination->destination_name); ?></td>
                                            <!-- Displaying destination name -->
                                            <td><?php echo e($hotel->hotel_name); ?></td> <!-- Displaying hotel name -->
                                            <td>
                                                <?php if($hotel->hotel_image): ?>
                                                    <img src="<?php echo e(asset($hotel->hotel_image)); ?>" alt="<?php echo e($hotel->hotel_name); ?>"
                                                        width="100" height="50">
                                                <?php else: ?>
                                                    No Image
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('hotels.edit', $hotel->id)); ?>" class="btn btn-warning">
                                                    <i class="bi bi-pencil-fill"></i>
                                                </a>
                                                <form action="<?php echo e(route('hotels.destroy', $hotel->id)); ?>" method="POST"
                                                    onsubmit="return confirm('Are you sure you want to delete this hotel?')"
                                                    style="display:inline;">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger mt-2">
                                                        <i class="bi bi-trash-fill"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <!-- Pagination -->
                            <div class="d-flex justify-content-between">
                                <div id="pagination-info">
                                    Showing <?php echo e($hotels->firstItem()); ?> to <?php echo e($hotels->lastItem()); ?> of
                                    <?php echo e($hotels->total()); ?> entries
                                </div>
                                <?php echo e($hotels->links()); ?> <!-- Pagination links -->
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    // Automatically close success message after 10 seconds
    setTimeout(function () {
        $('#message').alert('close');
    }, 10000);
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\unohotels\resources\views\admin\hotellist.blade.php ENDPATH**/ ?>