

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="page-inner">
        <div class="page-header">
            <h3 class="fw-bold mb-3">Country List</h3>
            <ul class="breadcrumbs mb-3">
                <li class="nav-home">
                    <a href="<?php echo e(route('dashboard')); ?>">
                        <i class="icon-home"></i>
                    </a>
                </li>
                <li class="separator">
                    <i class="icon-arrow-right"></i>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('countries.create')); ?>">Add New Country</a>
                </li>
                <li class="separator">
                    <i class="icon-arrow-right"></i>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('countries.index')); ?>">Country List</a>
                </li>
            </ul>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Country List</h4>
                        <!-- Success Message -->
                        <?php if(session('success')): ?>
                            <div class="alert alert-success" id="message" role="alert">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Country Name</th>
                                        <th>Image</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($country->country_name); ?></td>
                                            <td>
                                                <?php if($country->country_image): ?>
                                                    <img src="<?php echo e(asset('' . $country->country_image)); ?>"
                                                        alt="<?php echo e($country->country_name); ?>" width="100" height="50">
                                                <?php else: ?>
                                                    No Image
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('countries.edit', $country->id)); ?>"
                                                    class="btn btn-warning">Edit</a>
                                                <form action="<?php echo e(route('countries.destroy', $country->id)); ?>" method="POST"
                                                    onsubmit="return confirm('Are you sure you want to delete this country?')"
                                                    style="display:inline;">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger">Delete</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <!-- Pagination -->
                            <div class="d-flex justify-content-between">
                                <div id="pagination-info">
                                    Showing <?php echo e($countries->firstItem()); ?> to <?php echo e($countries->lastItem()); ?> of
                                    <?php echo e($countries->total()); ?> entries
                                </div>
                                <?php echo e($countries->links()); ?> <!-- Pagination links -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // Automatically close success message after 10 seconds
    setTimeout(function () {
        $('#message').alert('close');
    }, 10000);
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\unohotels\resources\views\admin\countrylist.blade.php ENDPATH**/ ?>