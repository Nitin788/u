

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="page-inner">
        <div class="page-header">
            <h3 class="fw-bold mb-3">Destination Form</h3>
            <ul class="breadcrumbs mb-3">
                <li class="nav-home">
                    <a href="<?php echo e(route('dashboard')); ?>">
                        <i class="icon-home"></i>
                    </a>
                </li>
                <!-- <li class="separator">
                    <i class="icon-arrow-right"></i>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('destinations.index')); ?>">Destination List</a>
                </li> -->
                <li class="separator">
                    <i class="icon-arrow-right"></i>
                    
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('destinations.create')); ?>">Add Destination Form</a>
                </li>
                <li class="separator">
                    <i class="icon-arrow-right"></i>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('countries.create')); ?>">Add Country </a>
                </li>
                <li class="separator">
                    <i class="icon-arrow-right"></i>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('hotels.create')); ?>">Add Hotel </a>
                </li>
            </ul>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <!-- Validation Errors -->
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger" role="alert" id="message">
                                <strong>Oops!</strong> There were some problems with your input.
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <!-- Success Message -->
                        <?php if(session('success')): ?>
                            <div class="alert alert-success" id="message" role="alert">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <h2>Create New Destination</h2>
                        <hr />
                        <form action="<?php echo e(route('destinations.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <!-- Country Selection -->
                                <div class="form-group col-md-6">
                                    <label for="country_id">Country</label>
                                    <select id="country_id" name="country_id" class="form-control" required>
                                        <option value="">Select a country</option>
                                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($country->id); ?>"><?php echo e($country->country_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <!-- Destination Name -->
                                <div class="form-group col-md-6">
                                    <label for="destination_name">Destination Name</label>
                                    <input type="text" class="form-control" id="destination_name"
                                        name="destination_name" required placeholder="Enter destination name">
                                </div>
                                <!-- Destination Image -->
                                <div class="form-group col-md-6">
                                    <label for="destination_image">Destination Image</label>
                                    <input type="file" class="form-control" id="destination_image"
                                        name="destination_image" placeholder="Upload destination image" required>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary mt-3">Create</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // Automatically close success message after 10 seconds
    setTimeout(function () {
        $('#message').alert('close');
    }, 10000);
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\unohotels\resources\views\admin\adddestination.blade.php ENDPATH**/ ?>