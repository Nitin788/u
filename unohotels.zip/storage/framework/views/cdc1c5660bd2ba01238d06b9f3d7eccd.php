

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="page-inner">
        <div class="page-header">
            <h3 class="fw-bold mb-3">Edit Hotel</h3>
            <ul class="breadcrumbs mb-3">
                <li class="nav-home">
                    <a href="<?php echo e(route('dashboard')); ?>">
                        <i class="icon-home"></i>
                    </a>
                </li>
                <li class="separator">
                    <i class="icon-arrow-right"></i>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('hotels.index')); ?>">Hotel List</a>
                </li>
                <li class="separator">
                    <i class="icon-arrow-right"></i>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('hotels.edit', $hotel->id)); ?>">Edit Hotel</a>
                </li>
            </ul>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <!-- Validation Errors -->
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger" role="alert" id="message">
                                <strong>Oops!</strong> There were some problems with your input.
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <h2>Edit Hotel</h2>
                        <hr />
                        <form action="<?php echo e(route('hotels.update', $hotel->id)); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="row">
                                <!-- Hotel Destination -->
                                <div class="form-group col-md-6">
                                    <label for="destination_id">Destination</label>
                                    <select id="destination_id" name="destination_id" class="form-control" required>
                                        <option value="">Select a destination</option>
                                        <?php $__currentLoopData = $destinations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $destination): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($destination->id); ?>" <?php echo e($hotel->destination_id == $destination->id ? 'selected' : ''); ?>>
                                                <?php echo e($destination->destination_name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <!-- Hotel Name -->
                                <div class="form-group col-md-6">
                                    <label for="hotel_name">Hotel Name</label>
                                    <input type="text" class="form-control" id="hotel_name" name="hotel_name" required
                                        value="<?php echo e(old('hotel_name', $hotel->hotel_name)); ?>" placeholder="Enter hotel name">
                                </div>

                                <!-- Hotel Image -->
                                <div class="form-group col-md-6">
                                    <label for="hotel_image">Hotel Image (Leave blank to keep current image)</label>
                                    <input type="file" class="form-control" id="hotel_image" name="hotel_image"
                                        placeholder="Upload hotel image">
                                    <?php if($hotel->hotel_image): ?>
                                        <div class="mt-2">
                                            <img src="<?php echo e(asset($hotel->hotel_image)); ?>" alt="Current Image" width="100" height="50">
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row">
                                <!-- Description Selection -->
                                <div class="form-group col-md-6">
                                    <label for="hotel_description">Hotel Description</label>
                                    <textarea class="form-control" id="hotel_description" name="hotel_description"
                                        rows="3" placeholder="Enter hotel description"><?php echo e(old('hotel_description', $hotel->hotel_description)); ?></textarea>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary mt-3">Update</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // Automatically close success message after 10 seconds
    setTimeout(function () {
        $('#message').alert('close');
    }, 10000);
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\unohotels\resources\views\admin\edithotel.blade.php ENDPATH**/ ?>